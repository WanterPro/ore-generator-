<?php

namespace OreSpawnerShop;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\plugin\PluginBase;

use pocketmine\event\Listener;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\utils\Config;

use onebone\economyapi\EconomyAPI;

use libs\FormAPI\SimpleForm;
use libs\FormAPI\CustomForm;

class Main extends PluginBase implements Listener {
    
    public $eco;
	
	public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
	}
	
	public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args):bool
    {
        switch($cmd->getName()){
        case "osshop":
        if($sender instanceof Player){
            $this->OreSpawnerShopFrom($sender);
            } else {
                $sender->sendMessage("§cYou can only use this command in-game");
            }
        }
        return true;
    }
	
	public function OreSpawnerShopFrom(Player $sender) { 
        $form = new SimpleForm(function (Player $sender, $data){
            $result = $data;
            if($result === null) {
                return true;
            }             
            switch($result) {
                case 0:
                break;
                case 1:
                    $this->CoalOreForm($sender);
                break;
                case 2:
                    $this->IronOreForm($sender);
                break;
                case 3:
                    $this->GoldOreForm($sender);
                break;
                case 4:
                    $this->DiamondOreForm($sender);
                break;
                case 5:
                    $this->EmeraldOreForm($sender);
                break;
                case 6:
                    $this->LapisOreForm($sender);
                break;
                case 7:
                    $this->RedstoneOreForm($sender);
                break;
       
            }
       });
       $form->setTitle("§lOre Spawner Shop");
       $form->setContent("Please select the Ore Spawner you want to buy!");
       $form->addButton("§l§cEXIT");
       $form->addButton("§lCoal Ore");
       $form->addButton("§lIron Ore");
       $form->addButton("§lGold Ore");
       $form->addButton("§lDiamond Ore");
       $form->addButton("§lEmerald Ore");
       $form->addButton("§lLapis Ore");
       $form->addButton("§lRedstone Ore");
       $form->sendToPlayer($sender);
       return $form;
   }
   
   public function CoalOreForm(Player $sender) { 
        $form = new CustomForm(function (Player $sender, $data){
            $result = $data;
            if($result === null) {
                $this->OreSpawnerShopFrom($sender);
                return true;
            }
            if(!empty($data[1])){
                if(is_numeric($data[1])){
                    $total = $data[1] * $this->getConfig()->get("coal-price");
                    $name = $sender->getName();
                        if($this->eco->myMoney($sender) >= $total){
                                $this->getServer()->dispatchCommand(new ConsoleCommandSender(), "os coal $data[1] $name");
                                $this->eco->reduceMoney($sender->getName(), $total);
                                $sender->sendMessage("§aYou Bought §b" . $data[1] . " §7Coal Ore Spawner §afor §e" . $total . "§d$");
                            }else{
                                $sender->sendMessage("§cYou do not have enough money!");
                            }
                            }else{
                            $sender->sendMessage("§cThe amount is not a number");
                        }
                    }else{
                        $sender->sendMessage("§cPlease specify an amount");
                    }
        });
        $form->addLabel("Your money: §a" . $this->eco->myMoney($sender) . "§6$ \n§rPrice Per Coal Ore Spawner: §a" . $this->getConfig()->get("coal-price") . "§6$");
        $form->setTitle("§lBuy Coal Ore Spawner");
        $form->addInput("§aThe Spawner Amount", "Enter the amount in here");
        $form->sendToPlayer($sender);
        return $form;
   }
   
   public function IronOreForm(Player $sender) { 
        $form = new CustomForm(function (Player $sender, $data){
            $result = $data;
            if($result === null) {
                $this->OreSpawnerShopFrom($sender);
                return true;
            }
            if(!empty($data[1])){
                if(is_numeric($data[1])){
                    $total = $data[1] * $this->getConfig()->get("iron-price");
                    $name = $sender->getName();
                        if($this->eco->myMoney($sender) >= $total){
                                $this->getServer()->dispatchCommand(new ConsoleCommandSender(), "os iron $data[1] $name");
                                $this->eco->reduceMoney($sender->getName(), $total);
                                $sender->sendMessage("§aYou Bought §b" . $data[1] . " §8Iron Ore Spawner §afor §e" . $total . "§d$");
                            }else{
                                $sender->sendMessage("§cYou do not have enough money!");
                            }
                            }else{
                            $sender->sendMessage("§cThe amount is not a number");
                        }
                    }else{
                        $sender->sendMessage("§cPlease specify an amount");
                    }
        });
        $form->addLabel("Your money: §a" . $this->eco->myMoney($sender) . "§6$ \n§rPrice Per Iron Ore Spawner: §a" . $this->getConfig()->get("iron-price") . "§6$");
        $form->setTitle("§lBuy Iron Ore Spawner");
        $form->addInput("§aThe Spawner Amount", "Enter the amount in here");
        $form->sendToPlayer($sender);
        return $form;
   }
   
   public function GoldOreForm(Player $sender) { 
        $form = new CustomForm(function (Player $sender, $data){
            $result = $data;
            if($result === null) {
                $this->OreSpawnerShopFrom($sender);
                return true;
            }
            if(!empty($data[1])){
                if(is_numeric($data[1])){
                    $total = $data[1] * $this->getConfig()->get("gold-price");
                    $name = $sender->getName();
                        if($this->eco->myMoney($sender) >= $total){
                                $this->getServer()->dispatchCommand(new ConsoleCommandSender(), "os gold $data[1] $name");
                                $this->eco->reduceMoney($sender->getName(), $total);
                                $sender->sendMessage("§aYou Bought §b" . $data[1] . " §6Gold Ore Spawner §afor §e" . $total . "§d$");
                            }else{
                                $sender->sendMessage("§cYou do not have enough money!");
                            }
                            }else{
                            $sender->sendMessage("§cThe amount is not a number");
                        }
                    }else{
                        $sender->sendMessage("§cPlease specify an amount");
                    }
        });
        $form->addLabel("Your money: §a" . $this->eco->myMoney($sender) . "§6$ \n§rPrice Per Gold Ore Spawner: §a" . $this->getConfig()->get("gold-price") . "§6$");
        $form->setTitle("§lBuy Gold Ore Spawner");
        $form->addInput("§aThe Spawner Amount", "Enter the amount in here");
        $form->sendToPlayer($sender);
        return $form;
   }
   
   public function DiamondOreForm(Player $sender) { 
        $form = new CustomForm(function (Player $sender, $data){
            $result = $data;
            if($result === null) {
                $this->OreSpawnerShopFrom($sender);
                return true;
            }
            if(!empty($data[1])){
                if(is_numeric($data[1])){
                    $total = $data[1] * $this->getConfig()->get("diamond-price");
                    $name = $sender->getName();
                        if($this->eco->myMoney($sender) >= $total){
                                $this->getServer()->dispatchCommand(new ConsoleCommandSender(), "os diamond $data[1] $name");
                                $this->eco->reduceMoney($sender->getName(), $total);
                                $sender->sendMessage("§aYou Bought §b" . $data[1] . " §bDiamond Ore Spawner §afor §e" . $total . "§d$");
                            }else{
                                $sender->sendMessage("§cYou do not have enough money!");
                            }
                            }else{
                            $sender->sendMessage("§cThe amount is not a number");
                        }
                    }else{
                        $sender->sendMessage("§cPlease specify an amount");
                    }
        });
        $form->addLabel("Your money: §a" . $this->eco->myMoney($sender) . "§6$ \n§rPrice Per Diamond Ore Spawner: §a" . $this->getConfig()->get("diamond-price") . "§6$");
        $form->setTitle("§lBuy Diamond Ore Spawner");
        $form->addInput("§aThe Spawner Amount", "Enter the amount in here");
        $form->sendToPlayer($sender);
        return $form;
   }
   
   public function EmeraldOreForm(Player $sender) { 
        $form = new CustomForm(function (Player $sender, $data){
            $result = $data;
            if($result === null) {
                $this->OreSpawnerShopFrom($sender);
                return true;
            }
            if(!empty($data[1])){
                if(is_numeric($data[1])){
                    $total = $data[1] * $this->getConfig()->get("emerald-price");
                    $name = $sender->getName();
                        if($this->eco->myMoney($sender) >= $total){
                                $this->getServer()->dispatchCommand(new ConsoleCommandSender(), "os emerald $data[1] $name");
                                $this->eco->reduceMoney($sender->getName(), $total);
                                $sender->sendMessage("§aYou Bought §b" . $data[1] . " §aEmerald Ore Spawner §afor §e" . $total . "§d$");
                            }else{
                                $sender->sendMessage("§cYou do not have enough money!");
                            }
                            }else{
                            $sender->sendMessage("§cThe amount is not a number");
                        }
                    }else{
                        $sender->sendMessage("§cPlease specify an amount");
                    }
        });
        $form->addLabel("Your money: §a" . $this->eco->myMoney($sender) . "§6$ \n§rPrice Per Emerald Ore Spawner: §a" . $this->getConfig()->get("emerald-price") . "§6$");
        $form->setTitle("§lBuy Emerald Ore Spawner");
        $form->addInput("§aThe Spawner Amount", "Enter the amount in here");
        $form->sendToPlayer($sender);
        return $form;
   }
   
   public function LapisOreForm(Player $sender) { 
        $form = new CustomForm(function (Player $sender, $data){
            $result = $data;
            if($result === null) {
                $this->OreSpawnerShopFrom($sender);
                return true;
            }
            if(!empty($data[1])){
                if(is_numeric($data[1])){
                    $total = $data[1] * $this->getConfig()->get("lapis-price");
                    $name = $sender->getName();
                        if($this->eco->myMoney($sender) >= $total){
                                $this->getServer()->dispatchCommand(new ConsoleCommandSender(), "os lapis $data[1] $name");
                                $this->eco->reduceMoney($sender->getName(), $total);
                                $sender->sendMessage("§aYou Bought §b" . $data[1] . " §7Lapis Ore Spawner §afor §e" . $total . "§d$");
                            }else{
                                $sender->sendMessage("§cYou do not have enough money!");
                            }
                            }else{
                            $sender->sendMessage("§cThe amount is not a number");
                        }
                    }else{
                        $sender->sendMessage("§cPlease specify an amount");
                    }
        });
        $form->addLabel("Your money: §a" . $this->eco->myMoney($sender) . "§6$ \n§rPrice Per Lapis Ore Spawner: §a" . $this->getConfig()->get("lapis-price") . "§6$");
        $form->setTitle("§lBuy Lapis Ore Spawner");
        $form->addInput("§aThe Spawner Amount", "Enter the amount in here");
        $form->sendToPlayer($sender);
        return $form;
   }
   
   public function RedstoneOreForm(Player $sender) { 
        $form = new CustomForm(function (Player $sender, $data){
            $result = $data;
            if($result === null) {
                $this->OreSpawnerShopFrom($sender);
                return true;
            }
            if(!empty($data[1])){
                if(is_numeric($data[1])){
                    $total = $data[1] * $this->getConfig()->get("redstone-price");
                    $name = $sender->getName();
                        if($this->eco->myMoney($sender) >= $total){
                                $this->getServer()->dispatchCommand(new ConsoleCommandSender(), "os redstone $data[1] $name");
                                $this->eco->reduceMoney($sender->getName(), $total);
                                $sender->sendMessage("§aYou Bought §b" . $data[1] . " §cRedstone Ore Spawner §afor §e" . $total . "§d$");
                            }else{
                                $sender->sendMessage("§cYou do not have enough money!");
                            }
                            }else{
                            $sender->sendMessage("§cThe amount is not a number");
                        }
                    }else{
                        $sender->sendMessage("§cPlease specify an amount");
                    }
        });
        $form->addLabel("Your money: §a" . $this->eco->myMoney($sender) . "§6$ \n§rPrice Per Redstone Ore Spawner: §a" . $this->getConfig()->get("redstone-price") . "§6$");
        $form->setTitle("§lBuy Redstone Ore Spawner");
        $form->addInput("§aThe Spawner Amount", "Enter the amount in here");
        $form->sendToPlayer($sender);
        return $form;
   }
}